import { WeaponStatsSerializer } from "./IPC/weapon_stats.ipc";
import { IPC, PROTO } from './IPC/ipc';
import { world } from "@minecraft/server";

const weaponStats = [
    {
        id: "minecraft:iron_ingot",
        attackSpeed: 1.6,
        damage: 8,
        isWeapon: true,
        sweep: true,
        beforeEffect: ({ mc, player, item }) => {
            const equippableComp = player.getComponent("equippable");
            const mainhand = equippableComp?.getEquipment("Mainhand");
            item.setLore([ "yeet" ]);
            equippableComp.setEquipment("Mainhand", item);
            function random(min, max) {
                return (Math.random() * (max - min) + min)
            }
            const rgb = {
                red: random(0,1),
                green: random(0,1),
                blue: random(0,1)
            }
            
            let map = new mc.MolangVariableMap();
			map.setFloat('variable.size', random(0.8,1));
			map.setColorRGB("variable.color", rgb);
			
			return {
				sweepMap: map
			}
        }
    },
    {
        id: "minecraft:netherite_sword",
        attackSpeed: 1.6,
        damage: 8,
        isWeapon: true,
        sweep: true,
        beforeEffect: ({ mc, player, item }) => {
            const equippableComp = player.getComponent("equippable");
            const mainhand = equippableComp?.getEquipment("Mainhand");
            item.setLore([ "yeet" ]);
            equippableComp.setEquipment("Mainhand", item);
            function random(min, max) {
                return (Math.random() * (max - min) + min)
            }
            const rgb = {
                red: random(0,1),
                green: random(0,1),
                blue: random(0,1)
            }
            let map = new mc.MolangVariableMap();
			map.setFloat('variable.size', random(0.8,1));
			map.setColorRGB("variable.color", rgb);
			
			return {
				sweepMap: map
			}
        },
        script: ({ player, hit }) => {
			if (hit) {
				player.sendMessage("Yeet!")
			}
		}
    }
]

world.afterEvents.worldInitialize.subscribe(event=> {
    IPC.send("sweep-and-slash:register-weapons", PROTO.Array(WeaponStatsSerializer), weaponStats)
})